package data;

import java.util.ArrayList;

public class Team {
	
	private String nameTeam; 
	private static ArrayList <Player> team ;
	private double scoreTeam;
	private double attack;
	private double midfield;
	private double defense;
	private int fifa; 
	
	public Team(String nameTeam) {
		super();
		team = new ArrayList<Player>() ;
		this.nameTeam = nameTeam;
		this.scoreTeam = scoreTeam;
	}

	public String getNameTeam() {
		return nameTeam;
	}

	public void setNameTeam(String nameTeam) {
		this.nameTeam = nameTeam;
	}

	public static ArrayList<Player> getTeam() {
		return team;
	}

	public static void setTeam(ArrayList<Player> team) {
		Team.team = team;
	}
	
	public double getscoreTeam() {
		return scoreTeam;
	}

	public void setScoreTeam(double scoreTeam) {
		this.scoreTeam = scoreTeam;
	}

	public double getAttack() {
		return attack;
	}

	public void setAttack(double attack) {
		this.attack = attack;
	}

	public double getMidfield() {
		return midfield;
	}

	public void setMidfield(double midfield) {
		this.midfield = midfield;
	}

	public double getDefense() {
		return defense;
	}

	public void setDefense(double defense) {
		this.defense = defense;
	}

	public int getFifa() {
		return fifa;
	}

	public void setFifa(int fifa) {
		this.fifa = fifa;
	}


}