package data;

public class PhysicalAspect {

	private int age ;
	private boolean wound;
	
	public PhysicalAspect(int age, boolean wound) {
		super();
		this.age = age;
		this.wound = wound;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean getWound() {
		return wound;
	}

	public void setWound(boolean wound) {
		this.wound = wound;
	}
	
	
}