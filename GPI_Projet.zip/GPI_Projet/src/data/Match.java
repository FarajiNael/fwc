package data;

public class Match {
	private Team t1;
	private Team t2;
	private int goalT1;
	private int goalT2;
	private double supportersT1;
	private double supportersT2;
	
	public Match() {
		
		
	}
	
	public void gagnant() {
		
		if (goalT1 > goalT2) {
			t1.setScoreTeam(t1.getscoreTeam()+3) ;
		}
		if (goalT2 > goalT1) {
			t2.setScoreTeam(t2.getscoreTeam()+3);
		}
		if (goalT1 == goalT2) {
			t1.setScoreTeam(t1.getscoreTeam()+1);
			t2.setScoreTeam(t2.getscoreTeam()+1);
		}
	}
	
	public int getGoalT1() {
		return goalT1;
	}

	public void setGoalT1(int goalT1) {
		this.goalT1 = goalT1;
	}

	public int getGoalT2() {
		return goalT2;
	}

	public void setGoalT2(int goalT2) {
		this.goalT2 = goalT2;
	}

	public double getSupportersT1() {
		return supportersT1;
	}

	public void setSupportersT1(double supportersT1) {
		this.supportersT1 = supportersT1;
	}

	public double getSupportersT2() {
		return supportersT2;
	}

	public void setSupportersT2(double supportersT2) {
		this.supportersT2 = supportersT2;
	}

	public Team getT1() {
		return t1;
	}


	public void setT1(Team t1) {
		t1 = t1;
	}


	public Team getT2() {
		return t2;
	}


	public void setT2(Team t2) {
		t2 = t2;
	}


	public int getGoalE1() {
		return goalT1;
	}


	public void setGoalE1(int goalE1) {
		this.goalT1 = goalT1;
	}


	public int getGoalE2() {
		return goalT2;
	}


	public void setGoalE2(int goalE2) {
		this.goalT2 = goalT2;
	}
	
	
	
	
	
	

}
