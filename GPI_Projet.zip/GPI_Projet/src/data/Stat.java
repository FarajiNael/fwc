package data;

public class Stat {
	
	private PhysicalAspect pa;
	private TechniqueAspect ta;
	private Team team;
	
	public double level3 () {
		int age = pa.getAge();
		boolean wound = pa.getWound();
		double physique = 10;
		if(age>30) {
			physique = physique - 1;
		}
		if(wound==true) {
			physique = physique - 3;
		}
		
		double finition = ta.getFinition();
		double speed = ta.getSpeed();
		double shotStopped = ta.getShotStopped();
		double agressiveness = ta.getAggressiveness();
	
		double technique = (finition + speed + shotStopped + agressiveness)/4;
		
		double lvl3 = (technique + physique*1.5)/2.5;
		
		
		return lvl3;
	}
	
	public double level2 () {
		double attack = team.getAttack();
		double midfield = team.getMidfield();
		double defense = team.getDefense();
		
		double lvl2 = (attack + midfield + defense)/3;
		
		return lvl2;
	}
}